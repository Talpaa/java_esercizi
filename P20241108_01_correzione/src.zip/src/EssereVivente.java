public abstract class EssereVivente {

	protected String coloreOcchi;
	
	abstract public void SetColoreOcchi(String s);
	abstract public String GetColoreOcchi(String s);
	
	
}
