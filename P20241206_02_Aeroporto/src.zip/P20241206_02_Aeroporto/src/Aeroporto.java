import java.util.Scanner;

public class Aeroporto {

	public static void Menu(CompagniaAerea alitalia) {
		//Menu per aeroporto
			//imbarco
			//decollo
	    	//atterraggio
		Scanner input = new Scanner(System.in);
		
		Integer operazione = 0;
		Boolean ris = true;
		
		do {
			System.out.println("1) Imbarco;");
			System.out.println("2) Decollo;");
			System.out.println("3) Atterraggio;");
			System.out.println("4) Exit");
			System.out.print("Quale operazione vuoi eseguire(Digitare il numero associato): ");
			operazione = input.nextInt(); 
			
			switch (operazione) {
			case 1: {
				
				System.out.print("Di quale volo vuoi chiudere l'imbarco: ");
				String nomeVolo = input.next();
				Volo volo = alitalia.TrovaVolo(nomeVolo);
				
				if ((volo.getNome().equals(null))) {
					System.out.println("Non esiste nessun volo con questo nome.");
				}else {
					volo.setImbarco(false);
					System.out.println("l'Imbarco del volo" + volo.getNome() + " è stato chiuso.");
				}
				break;
			}
			case 2: {
				
				System.out.print("Di quale volo vuoi sapere l'orario di decollo: ");
				String nomeVolo = input.next();
				Volo volo = alitalia.TrovaVolo(nomeVolo);
				
				if (volo == null) {
					System.out.println("Non esiste nessun volo con questo nome.");
				}else {

					System.out.println("L'orario di decollo del volo " + volo.getNome() + " è " + volo.getDecollo() + ".");
				}
				break;
			}
				
			case 3: {

				System.out.print("Di quale volo vuoi sapere l'orario di decollo: ");
				String nomeVolo = input.next();
				Volo volo = alitalia.TrovaVolo(nomeVolo);
				
				if (volo == null) {
					System.out.println("Non esiste nessun volo con questo nome.");
				}else {

					System.out.println("L'orario di atterraggio del volo " + volo.getNome() + " è " + volo.getAtteraggio() + ".");
				}
				break;
			}
			case 4: {

				ris = false;
				input.close();
				break;
			}
			default:
				System.out.println("Il menu " + operazione + " non esiste.");;
			}
			
		}while(ris);
		
	}
}
