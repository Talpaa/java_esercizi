import java.util.Scanner;

public class Agenzia {

	public static void Menu(CompagniaAerea alitalia) {
		//Menu per compagnia aerea
			//crea aereo
			//elimina aereo
		Scanner input = new Scanner(System.in);
		
		Integer operazione = 0;
		Boolean ris = true;
		
		do {
			
			//Menu Generale
			System.out.println("1) Crea aereo;");
			System.out.println("2) Elimina aereo;");
			System.out.println("3) Exit");
			System.out.print("Quale operazione vuoi eseguire(Digitare il numero associato): ");
			operazione = input.nextInt(); 
			
			switch (operazione) {
			case 1: {
				System.out.print("Quale è il nome dell'aereo che vuoi creare: ");
				String nomeAereo = input.next();
				
				System.out.print("Quale è il numero di posti disponibili sull'aereo che vuoi creare: ");
				Integer posti = input.nextInt();
				
				alitalia.CreaAereo(nomeAereo, posti);
				break;
			}
			case 2: {

				System.out.print("Quale è il nome dell'aereo che vuoi eliminare: ");
				String nomeAereo = input.next();
				
				alitalia.EliminaAereo(nomeAereo);
				break;
			}
			case 3: {

				ris = false;
				input.close();
				break;
			}
			default:
				System.out.println("Il menu " + operazione + " non esiste.");;
			}
			
		}while(ris);
		
	}
}
