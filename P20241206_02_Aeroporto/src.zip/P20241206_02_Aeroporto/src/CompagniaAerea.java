import java.util.LinkedList;
import java.util.Scanner;

public class CompagniaAerea {

	private LinkedList<Aereo> aerei = new LinkedList<Aereo>();
	private LinkedList<Volo> voli = new LinkedList<Volo>();
	
	
	public CompagniaAerea() {
		super();
	}
	
	public CompagniaAerea(LinkedList<Aereo> aerei, LinkedList<Volo> voli) {
		super();
		this.aerei = aerei;
		this.voli = voli;
	}


	public LinkedList<Aereo> getAerei() {
		return aerei;
	}
	public void setAerei(LinkedList<Aereo> aerei) {
		this.aerei = aerei;
	}
	public LinkedList<Volo> getVoli() {
		return voli;
	}
	public void setVoli(LinkedList<Volo> voli) {
		this.voli = voli;
	}
	
	public Volo CreaVolo(String nome, String partenza, String arrivo, Aereo aereo, String decollo, String atteraggio){
		
		Volo volo = new Volo(nome, partenza, arrivo, aereo, decollo, atteraggio);
		voli.add(volo);
		return volo;
		
	}
	public void CancellaVolo(String nomeVolo){
		
		for (Volo volo : voli) {
			
			if (volo.getNome() == nomeVolo) {
				voli.remove(volo);
			}
		}
	}
	
	public Aereo CreaAereo(String nomeAereo, Integer posti){
		
		Aereo aereo = new Aereo(nomeAereo, posti);
		aerei.add(aereo);
		System.out.println("\n Aereo creato.");
		return aereo;
	}
	public void EliminaAereo(String nomeAereo){
		
		for (Aereo aereo : aerei) {
			
			if (aereo.getNome() == nomeAereo) {
				
				for (Volo volo : voli) {
					
					if (volo.getAereo()== aereo) {
						
						voli.remove(volo);
					}
				}
				aerei.remove(aereo);

				System.out.println("\n Aereo cancellato e tutti i voli a lui associato.");
			}
		}
	}
	
	public void PrenotaVolo(String nomeVolo, Integer posti) {
		
		for (Volo volo : voli) {
			
			if (volo.getNome() == nomeVolo) {
				
				volo.PrenotaVolo(posti);
			}
		}
	}
	public void CancellaPrenotazione(String nomeVolo, Integer posti) {
		
		for (Volo volo : voli) {
			
			if (volo.getNome() == nomeVolo) {
				
				volo.CancellaPrenotazione(posti);
			}
		}
	}
	
	public Aereo TrovaAereo(String nomeAereo) {
		
		for (Aereo aereo : aerei) {
			if (aereo.getNome() == nomeAereo) {
				return(aereo);
			}
		}
		
		return null;
		 
	}
	
	public Volo TrovaVolo(String nomeVolo) {
		
		for (Volo volo: voli) {
			if (volo.getNome().equals(nomeVolo)) {
				return(volo);
			}
		}
		
		return null;
		 
	}
	
	public void Menu() {
		
		//Menu per agenzia
			//prenotazione
			//disdetta
		
		Scanner input = new Scanner(System.in);
		
		Integer operazione = 0;
		Boolean ris = true;
		
		do {
			System.out.println("1) Prenotazione;");
			System.out.println("2) Disdetta;");
			System.out.println("3) Exit");
			System.out.println("Quale operazione vuoi eseguire(Digitare il numero associato): ");
			operazione = input.nextInt(); 
			
			switch (operazione) {
			case 1: {
				System.out.print("Quale è il nome del volo che vuoi prenotare: ");
				String nomeVolo = input.next();
				
				System.out.print("Quale è il numero di posti che vuoi prenotare sul volo: ");
				Integer posti = input.nextInt();
				
				PrenotaVolo(nomeVolo, posti);
				
				break;
			}
			case 2: {

				System.out.print("Quale è il nome del volo che vuoi disdire: ");
				String nomeVolo = input.next();
				
				System.out.print("Quale è il numero di posti che vuoi disdire sul volo: ");
				Integer posti = input.nextInt();
				
				CancellaPrenotazione(nomeVolo, posti);
				break;
			}
			case 3: {

				ris = false;
				input.close();
				break;
			}
			default:
				System.out.println("Il menu " + operazione + " non esiste.");;
			}
			
		}while(ris);
	}
}
