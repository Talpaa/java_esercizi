import java.util.LinkedList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		
		Scanner myObj = new Scanner(System.in);
		Boolean ris = true;
		Integer menu = 0;

		LinkedList<Volo> voli = new LinkedList<Volo>(); 
		LinkedList<Aereo> aerei = new LinkedList<Aereo>(); 
		
		CompagniaAerea alitalia = new CompagniaAerea(aerei, voli);

		alitalia.CreaAereo("a1", 251);
		
		alitalia.CreaVolo("v1", "Roma", "Milano", alitalia.getAerei().getFirst(), "12:00", "13:00");
	
		alitalia.PrenotaVolo("v1", 10);
		
		Integer posti = alitalia.getVoli().getFirst().getAereo().getPostiDis();
		System.out.println(posti);
		
		
		alitalia.CancellaPrenotazione("v1", 5);
		posti = alitalia.getVoli().getFirst().getAereo().getPostiDis();
		System.out.println(posti);
		
		alitalia.CancellaPrenotazione("v1", 6);
		posti = alitalia.getVoli().getFirst().getAereo().getPostiDis();
		System.out.println(posti);
		
		do {
			
			System.out.println("1) Menu per agenzia;");
			System.out.println("2) Menu per aeroporto;");
			System.out.println("3) Menu per compagnia aerea;");
			System.out.println("4) Termina sessione");
			System.out.print("Quale menu vuoi visualizzare(Digitare il numero associato): ");
			
			menu = myObj.nextInt(); 
			
			switch (menu) {
			case 1: {
				
				Agenzia.Menu(alitalia);
				
				break;
			}
			case 2: {
				
				Aeroporto.Menu(alitalia);
				break;
			}
			case 3: {
	
				alitalia.Menu();
				break;
			}
			case 4: {
				
				ris = false;
				myObj.close();
				break;
			}
			default:
				System.out.println("Il menu " + menu + " non esiste.");;
			}
			
		}while(ris);
	}
}
